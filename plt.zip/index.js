const fetch = require('node-fetch');
const cheerio = require('cheerio');
const { faker } = require('@faker-js/faker');
const chalk = require('chalk');
const moment = require('moment');
const readlineSync = require('readline-sync');
const fs = require('fs');


const getEmailRandom = (email, domain) => new Promise((resolve, reject) => {
    fetch(`https://generator.email/`, {
        method: "get",
        headers: {
            accept:
                "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,/;q=0.8,application/signed-exchange;v=b3",
            "accept-encoding": "gzip, deflate, br"
        }
    })
        .then(res => res.text())
        .then(text => {
            const $ = cheerio.load(text);
            const result = [];
            $('.e7m.tt-suggestions').find('div > p').each(function (index, element) {
                result.push($(element).text());
            });
            resolve(result);
        })
        .catch(err => reject(err));
});


const fakeName = () => {
    const randomName = faker.name.findName().toLowerCase();
    const random1 = faker.word.adjective().toLowerCase();
    const random2 = faker.word.adverb().toLowerCase();
    const name = random1 + randomName;
    return name.replace(/\s/g, "")
};


const randstr = length => {
    var text = "";
    var possible =
        "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz";

    for (var i = 0; i < length; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
};

const functionGetLink = (email, domain) => new Promise((resolve, reject) => {
    fetch(`https://generator.email/${domain}/${email}`, {
        method: "get",
        headers: {
            accept:
                "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,/;q=0.8,application/signed-exchange;v=b3",
            "accept-encoding": "gzip, deflate, br",
            cookie: `_ga=GA1.2.659238676.1567004853; _gid=GA1.2.273162863.1569757277; embx=%5B%22${email}%40${domain}%22%2C%22hcycl%40nongzaa.tk%22%5D; _gat=1; io=io=tIcarRGNgwqgtn40O${randstr(3)}; surl=${domain}%2F${email}`,
            "upgrade-insecure-requests": 1,
            "user-agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36"
        }
    })
        .then(res => res.text())
        .then(text => {
            const $ = cheerio.load(text);
            const src = $("#email-table > div.e7m.row.list-group-item > div.e7m.col-md-12.ma1 > div.e7m.mess_bodiyy > p:nth-child(4) > span").text()
            resolve(src);
        })
        .catch(err => reject(err));
});

const createAccount = (name, email, reff) => new Promise((resolve, reject) => {
    fetch('https://api.pltplace.io/api/v1/account', {
        method: 'POST',
        headers: {
            'authority': 'api.pltplace.io',
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'id-ID,id;q=0.9',
            'content-type': 'application/json;charset=UTF-8',
            'origin': 'https://pltplace.io',
            'referer': 'https://pltplace.io/',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36'
        },
        body: JSON.stringify({ "name": name, "email": email, "password": "id-ID,id;q=0.9", "referral_code": reff })
    })
        .then(res => res.text())
        .then(res => resolve(res))
        .catch(err => reject(err));
});

const emailVerification = (link) => new Promise((resolve, reject) => {
    fetch(`https://api.pltplace.io/api/v1/account/email/activate?activate_code${link.split('activate_code')[1]}`, {
        method: 'GET',
        headers: {
            'authority': 'api.pltplace.io',
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'id-ID,id;q=0.9',
            // 'cookie': '_ga=GA1.1.1293570422.1650130398; _SESSION=sqF0AgQXlKZJ0P8aQ4vE5xrE5DvnGitsaxbdgAi0u4oFHEsdSNataofz0zlQphaR; _ga_GRCBX0H0V3=GS1.1.1650130398.1.1.1650130824.0',
            'origin': 'https://pltplace.io',
            'referer': 'https://pltplace.io/',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36'
        }
    })
        .then(res => res)
        .then(res => resolve(res.headers.raw()))
        .catch(err => reject(err));
});


(async () => {

    const refferal = readlineSync.question('Masukin refferal : ');

    if (!refferal) {
        console.log(`[ ${moment().format("HH:mm:ss")} ] `, chalk.red(`Masukin refferalnya anjoy`));
        process.exit(0);
    }

    const piroRefE = readlineSync.question('Mau berapa reffnya ? ');

    for (let index = 0; index < parseInt(piroRefE); index++) {
        const domainList = await getEmailRandom();
        const domain = domainList[Math.floor(Math.random() * domainList.length)];
        const name = fakeName().replace("'", '');
        const email = `${name}@${domain}`;
        console.log('')
        console.log(`[ ${moment().format("HH:mm:ss")} ] `, chalk.green(`Registering email ${email}`));

        const resultCreateAccount = await createAccount(name, email, refferal);
        if (!resultCreateAccount) {
            console.log(`[ ${moment().format("HH:mm:ss")} ] `, chalk.green(`Waiting email confirmation link.`));
            let linkVerification;
            do {
                linkVerification = await functionGetLink(name, email.split('@')[1]);
            } while (!linkVerification)

            await emailVerification(linkVerification);
            console.log(`[ ${moment().format("HH:mm:ss")} ] `, chalk.green(`Done, check mas...`));
        }
    }

    // const refferal = 'txzd5LNT';



})();